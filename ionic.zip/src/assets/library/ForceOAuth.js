import { InAppBrowser } from '@ionic-native/in-app-browser';

  const ForceOAuth = {
  
     login:(loginUrl, clientId, callbackUrl, successCallback, errorCallback, proxyUrl) => {
        if (typeof loginUrl !== 'string')
           throw new TypeError('loginURL should be of type String');
           // this.loginUrl = loginUrl;

        if (typeof clientId !== 'string')
            throw new TypeError('consumerKey should be of type String');
            //this.clientId = clientId;
    
        if (typeof callbackUrl !== 'string')
            throw new TypeError('callbackURL should be of type String');
            //this.callbackUrl = callbackUrl;
    
        if (typeof successCallback !== 'function')
            throw new TypeError('successCallback should of type Function');
           // this.successCallback = successCallback;
    
        if (typeof errorCallback !== 'undefined' && typeof errorCallback !== 'function')
            throw new TypeError('errorCallback should of type Function');
            //this.errorCallback = errorCallback;
            
            var winHeight = 524,
                winWidth = 674,
                centeredY = window.screenY + (window.outerHeight / 2 - winHeight / 2),
                centeredX = window.screenX + (window.outerWidth / 2 - winWidth / 2);

            var authUrl = `${loginUrl}services/oauth2/authorize?&response_type=token&client_id=${(clientId)}&redirect_uri=${(callbackUrl)}`

            var loginWindow = InAppBrowser.create(authUrl, '_blank', 'clearcache=yes,location=no,clearsessioncache=yes')

            var loc;
            console.log('in the login function',loginWindow)
            console.log('InApp browser',InAppBrowser)
            loginWindow.on('loadstart').subscribe(event => {
                console.log('load start',event)
                loc = event.url;
              });
            loginWindow.on('loadstop').subscribe(event => {
                console.log('load stop',event)
                loc = event.url;
                if (typeof(loc) !== 'undefined' && loc.indexOf(callbackUrl) == 0) {
                    loginWindow && loginWindow.close();
                    //clearInterval(interval);
                    console.log('auth callback ','#' + loc.split('#')[1])
                    //accessToken=loc.split('#')[1];
                     oauthCallback('#' + loc.split('#')[1],successCallback,errorCallback);
                }else{
                    //console.log('some error',event)
                }
              });

     },

      logout: function logout(logoutCallback) {
      },

     
    };
    
  const oauthCallback= (locHash,successCallback,errorCallback) => {
    var fragment = (locHash || window.location.hash).split("#")[1];
    let oauthResponse = {};

     if (fragment) {
            oauthResponse['response'] = fragment;
            var nvps = fragment.split('&');
            for (var nvp in nvps) {
                var parts = nvps[nvp].split('=');

                //Note some of the values like refresh_token might have '=' inside them
                //so pop the key(first item in parts) and then join the rest of the parts with =
                var key = parts.shift();
                var val = parts.join('=');
                oauthResponse[key] = decodeURIComponent(val);
            }
     }

     if (typeof oauthResponse.access_token === 'undefined') {
         if (errorCallback)
            return errorCallback({code: 0, message: 'Unauthorized - no OAuth response!'});
         else
             console.log('ERROR: No OAuth response!')
     } else {
         if (successCallback) {
            return successCallback(oauthResponse);
             window.location.hash = "";
         } else {
             console.log('INFO: OAuth login successful!')
             return oauthResponse
         }
        }
    }
export default ForceOAuth
