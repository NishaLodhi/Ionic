import React from 'react';
import './ExploreContainer.css';
import ForceOAuth from '../assets/library/ForceOAuth'
import jsforce from 'jsforce'
import { HTTP } from '@ionic-native/http';
// import jsforce from '../assets/library/jsforce'

const ExploreContainer = () => {
  let oauthClient ={};
  var loginUrl = "https://partial-mimithealth.cs71.force.com/MIMITHealthPortal/";
   var clientId ="3MVG9M6Iz6p_Vt2wUtGEy0Gm5jHSKv486JmxjeoOeLYbU.Sss_5rT8J528PwvYcYkTVdOWDCX2yhqcQeKHSie";
  var clientSecret="5183091F398A5EF06CE6506954DFD6142828FCA8813F5A9713E836011ED97AFA";
  var callbackUrl ="https://partial-mimithealth.cs71.force.com/MIMITHealthPortal/s/services/oauth2/authorize";
  //var RefreshLoginUrl = "https://login.salesforce.com";
  var accessToken;

  const forceOAuthUI_successHandler = (response) =>{
    oauthClient=response;
    var conn = new jsforce.Connection({
      oauth2: {
          loginUrl: loginUrl,
          clientId: clientId,
          clientSecret: clientSecret,
          redirectUri: callbackUrl

      },
      instanceUrl: oauthClient.instance_url,
      accessToken: oauthClient.access_token,
      //proxyUrl: '/services/proxy',
      refreshToken: oauthClient.refresh_token

    });
    // var headers = new Headers();
    // headers.append('Accept', 'application/json');
    // headers.append('Content-Type', 'application/json');
    // headers.append('Authorization', 'Bearer ' + oauthClient.access_token);

    const headers = new Headers();
    HTTP.setHeader('*', String("Content-Type"), String("application/json"));
    HTTP.setHeader('*', String("Accept"), String("application/json"));
    HTTP.setHeader('*', String("Authorization"), String("Bearer "+oauthClient.access_token));

    HTTP.get('https://mimit--partial.cs71.my.salesforce.com/services/data/v43.0/sobjects/Contact/describe', {},  headers)
    .then(data => {
  
      console.log('success',data);
  
    })
    .catch(error => {
  
      console.log('error',error);
  
    });
    conn.sobject("Contact").find(
      { LastName : { $like : 'A%' }}
    ).execute(function(err, records) {
       if (err) { return console.log('error from salesforce',err); }
       else{
        console.log("fetched : " + records);
       }
    });
    
  }
  const forceOAuthUI_errorHandler = (error) =>{
    console.log('login error')
  }
  const Login = () =>{

    console.log('env info ', process.env)

    //console.log('ForceOAuth ',ForceOAuth)
    
    ForceOAuth.login(loginUrl, clientId, callbackUrl,forceOAuthUI_successHandler,forceOAuthUI_errorHandler)
    console.log('oauthClient ',oauthClient)

    
  }

  return (
    <div className="container">
      <button onClick={Login}> Mimit community HTTP</button>
     </div>
  );
};

export default ExploreContainer;
